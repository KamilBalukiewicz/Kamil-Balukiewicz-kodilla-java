class UserValidator {
	
	public boolean validateName(String name) {
		if (name == null) {
			System.out.println("There's no user");
			return false;
		} else {
			System.out.println("Hello " + name);
			return true;
			
		}
	}
   
   public boolean validateAge(double age) {
   	if (age < 30) {
   		System.out.println("User is younger than 30 or lower than 160cm");
   		return false;
   	} else {
   		return true;
   		
   	}
   }
   	
   	public boolean validateHeight(double height) {
   		if (height < 160) {
   			System.out.println("User is younger than 30 or lower than 160cm");
   			return false;
   		} else {
   			System.out.println("User is older than 30 and higher than 160cm");
   			return true;
   			
   		}
   		
   	}
   	
   
   	
   }
   
   
   class Application
   {
   	public static void main(String[] args) throws java.lang.Exception
   	{
   		System.out.println("Starting...");
   	
   		
   		String name = "Adam";
        double age = 40.5;
   		double height = 178;
   		
   		
   		UserValidator validator = new UserValidator();
   		
   		boolean userNameExists = validator.validateName(name);
   		
   	    boolean isOlderThan30 = validator.validateAge(age);
   	
   	if(isOlderThan30) {
   		validator.validateHeight(height);
   		
   	}
   	
   		
   		System.out.println("End of program");
   		
   	
   }
}