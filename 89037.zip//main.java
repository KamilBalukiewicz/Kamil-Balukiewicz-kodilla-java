import java.util.*;
import java.lang.*;
import java.io.*;
import java.time.*;

class Book {
	String title;
	String author;
	int year;
	
	public Book(String title, String author, int year) {
		this.title = title;
	    this.author = author;
	    this.year = year;
	}
	
	public String toString() {
		return "Book: \"" + title + "\" by " + author + ", " + year;
	}
	
	public String getTitle() {
		return title;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public int getYear() {
		return year;
	}
}

class BooksStack {
	public static void main (String[] args) throws java.lang.Exception {
		
		Book book1 = new Book("Brave New World", "Aldous Huxley", 1932);
		Book book2 = new Book("Miecz Przeznaczenia", "Andrzej Sapkowski", 1992);
		Book book3 = new Book("Dodger", "Terry Pratchett", 2012);
		Book book4 = new Book("Nineteen Eighty-Four", "George Orwell", 1949);
		Book book5 = new Book("The Empty Throne", "Bernard Cornwell", 2014);
		
		ArrayDeque<Book> books = new ArrayDeque<Book>();
		
		System.out.println("The queue is created. Size: " + books.size());
		
		books.push(book1);
		books.push(book2);
		books.push(book3);
		books.push(book4);
		books.push(book5);
		
		System.out.println("Books added to the Queue. Current size: " + books.size());
		System.out.println();
		
		Book temporaryBook;
		temporaryBook = books.pop();
		temporaryBook = books.pop();
		temporaryBook = books.pop();
		temporaryBook = books.pop();
		temporaryBook = books.pop();
		System.out.println("All books removed from the Queue. Size is: " + books.size());
		System.out.println();
		System.out.println("Last position in the Queue was " + temporaryBook);
		
	}
}
		
		
		