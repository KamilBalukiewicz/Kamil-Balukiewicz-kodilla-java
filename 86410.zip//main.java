interface Employee {
 
	double calculateSalary();
 
}
 
class FixedSalaryEmployee implements Employee {
 
	private double salary;
 
	public FixedSalaryEmployee(double salary) {
		this.salary = salary;
	}
 
	public double calculateSalary() {
		return this.salary;
	}
 
}
 
class HourlySalaryEmployee implements Employee {
 
	private double hours;
	private double hourlyPay;
 
	public HourlySalaryEmployee(double hours, double hourlyPay) {
		this.hours = hours;
		this.hourlyPay = hourlyPay;
	}
 
	public double calculateSalary() {
		return this.hourlyPay * this.hours;
	}
 
}

class PieceworkEmployee implements Employee {
	
	private double pieces;
	private double payPerPiece;
	
	public PieceworkEmployee(double pieces, double payPerPiece) {
		this.pieces = pieces;
		this.payPerPiece = payPerPiece;
	}
	
	public double calculateSalary() {
		return this.payPerPiece * this.pieces;
	}
	
}

class BonusEmployee implements Employee {
	
	private double basicSalary;
	private double bonus;
	private boolean extraSale;
	
	public BonusEmployee(double basicSalary, double bonus, boolean extraSale) {
		this.basicSalary = basicSalary;
		this.bonus = basicSalary * 0.2;
		this.extraSale = extraSale;
	}
	
	public double calculateSalary() {
		
		if(extraSale) {
		return this.basicSalary + bonus;
	 
		} else {
			return this.basicSalary;
		}
	}
	
}
	
// Payout 
abstract class SalaryPayout {
 
	private Employee employee;
 
	public SalaryPayout(Employee employee) {
		this.employee = employee;
	}
 
	protected abstract void payout();
 
	public void processPayout() {
		System.out.println("Creating payout for: " + this.employee.calculateSalary() + " PLN");
		this.payout();
		System.out.println("Payout has been completed!");
	}
 
}
 
class SalaryPayoutProcessor extends SalaryPayout {
 
	public SalaryPayoutProcessor(Employee employee) {
		super(employee);
	}
 
	protected void payout() {
		System.out.println("Sending money to employee");
	}
 
}
 
class Application {
 
	public static void main(String args[]) {
 
		FixedSalaryEmployee employee = new FixedSalaryEmployee(2000);
		HourlySalaryEmployee employee1 = new HourlySalaryEmployee(40, 19);
		PieceworkEmployee employee2 = new PieceworkEmployee(10, 5);
		BonusEmployee employee3 = new BonusEmployee(2000, 2000, false);
 
		SalaryPayoutProcessor processor = new SalaryPayoutProcessor(employee3);
		processor.processPayout();
 
	}
 
}