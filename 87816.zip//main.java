class Compare {
		public static void main(String args[]) throws java.lang.Exception
	
	{
	
	int n = 10;
	
	double k = 3.14;
	
	char l = 'L';
	
	Integer m = 10;
	
	Double g = 3.14;
	
	Character h = 'L';
	
	
	System.out.println(n == m);
	
	System.out.println(k == g);
	
	System.out.println(l == h);
}
}
	

	
	
  