import java.util.*;
import java.lang.*;
import java.io.*;
import java.time.*;

class Book {
	String title;
	String author;
	LocalDate publishDate;
	
	public Book(String title, String author, int yearOfPublishing, int monthOfPublishing, int dayOfPublishing) {
		this.title = title;
		this.author = author;
		this.publishDate = LocalDate.of(yearOfPublishing, monthOfPublishing, dayOfPublishing);
	}
	
	public int hashCode() {
		return publishDate.getYear();
	}
	
	public boolean equals(Object o) {
		Book b = (Book) o;
		return (title.equals(b.getTitle())) &&
		(author.equals(b.getAuthor())) &&
		(publishDate.getYear() == b.getPublishDate().getYear()) &&
		(publishDate.getMonthValue() == b.getPublishDate().getMonthValue()) &&
		(publishDate.getDayOfMonth() == b.getPublishDate().getDayOfMonth());
		
	}
	
	public String toString() {
		return title + " published " + publishDate;
	}
	
	public String getTitle() {
		return title;
	}
	
	public String getAuthor() {
		return author;
	}
	
	public LocalDate getPublishDate() {
		return publishDate;
	}
}

class BooksHashSet {
	
	public static void main (String[] args) throws java.lang.Exception
	{
		Book book1 = new Book("Brave New World", "Aldous Huxley", 1932, 1, 1);
		Book book2 = new Book("Miecz Przeznaczenia", "Andrzej Sapkowski", 1992, 1, 1);
		Book book3 = new Book("Dodger", "Terry Pratchett", 2012, 1, 1);
		Book book4 = new Book("Nineteen Eigthy-Four", "George Orwell", 1949, 1, 1);
		Book book5 = new Book("The Empty Throne", "Bernard Cornwell", 2014, 1, 1);
		Book book6 = new Book("Little Fires Everywhere", "Celeste Ng", 2017, 1, 1);
		
		HashSet<Book> booksSet = new HashSet<Book>();
		booksSet.add(book1);
		booksSet.add(book2);
		booksSet.add(book3);
		booksSet.add(book4);
		booksSet.add(book5);
		booksSet.add(book6);
		
		for(Book theBook : booksSet) {
			if(theBook.getPublishDate().getYear() < 2010) {
				System.out.println(theBook);
			};
		}
	}
}