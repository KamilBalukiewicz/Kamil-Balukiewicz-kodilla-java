interface Quest {
	
	void process();
	
	String name();
	
}

class DeadIslandQuest implements Quest {
	
	public void process() {
		System.out.println("I'm going to kill all the undead on the Dead Island");
		
	}
	
	public String name() {
		return "Dead Island Quest";
	}
}

class EliteKnightQuest implements Quest {
	
	public void process() {
		System.out.println("I'm going to fight the Black Knight");
		
	}
	
	public String name() {
		return "Elite Knight Quest";
	}
}

class Knight {
	
	private Quest quest;
	
	public Knight(Quest quest) {
		this.quest = quest;
	}
	
	public void action() {
		System.out.println("Going for a chosen quest...");
		this.quest.process();
		System.out.println(quest.name() + " has been accomplished");
	}
	
}

class Application {
	
	public static void main(String args[]) {
		
		Quest eliteKnightQuest = new EliteKnightQuest();
		
		Knight knight = new Knight(eliteKnightQuest);
		
		knight.action();
		
	}
}
	



