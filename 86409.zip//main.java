abstract class Bank {
	
   private void insertCard() {
   	
   	System.out.println("Insert your card, please");
   }
   
   private void enterPIN() {
   	
   	System.out.println("Enter your PIN");
   }
   
   private void amount() {
   	
   	System.out.println("Please choose an amount you would like to withdraw");
   }
   
   abstract protected void requestAccepted();
   
   abstract protected void balanceCheck();
   
   abstract protected void eligibility();
   
   private void withdrawal() {
   	
   	System.out.println("Take your money, please");
   }
   private void thankYou() {
   	
   	System.out.println("Thank you for choosing our bank");
   }
   
   public void run() {
   	this.insertCard();
   	this.enterPIN();
   	this.amount();
   	this.requestAccepted();
   	this.balanceCheck();
   	this.eligibility();
   	this.withdrawal();
   	this.thankYou();
   }
   
}

class ATM extends Bank {
	
	protected void requestAccepted() {
		
		System.out.println("Your request has been accepted");
	}
	
	protected void balanceCheck() {
		
		System.out.println("Please wait. We are checking your balance");
	}
	
	protected void eligibility() {
		
		System.out.println("You are eligible for the withdrawal. Please wait for the money");
	}
	
}

class Application {
	
	public static void main(String args[]) {
		
		ATM atm = new ATM();
		
		atm.run();
		
	}
	
}

