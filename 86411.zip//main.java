class KamilsObject {
	
}

class Application {
	
	public static void main(String args[]) throws java.lang.Exception
	{
		KamilsObject obj = new KamilsObject();
		int result = obj.hashCode();
		
		System.out.println(result);
	}
}
		
		