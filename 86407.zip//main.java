interface ATM {
	
	void deposit();
	
	void withdrawal(); 
		
		default void connection() {
		System.out.println("Connected with the bank");
	}
	static String finishOperation() {
		return "Your operation has been completed. Take your card, please.";
	}
   
}

class ATMImpl implements ATM {
	
	public void deposit() {
		System.out.println("Deposit has been made");
	}
	public void withdrawal() {
		System.out.println("Please take your money");
	}
	
}

class Application {
	
	public static void main(String[] args) throws java.lang.Exception 
	{

    ATMImpl atmimpl = new ATMImpl();
    
    atmimpl.connection();
    
    atmimpl.deposit();
    
    atmimpl.withdrawal();
    
	System.out.println(ATM.finishOperation());
	
}
}
	